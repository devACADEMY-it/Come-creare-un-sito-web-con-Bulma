$(() => {
  $("#scroll-to-top").click(e => {
    e.preventDefault();
    $("html, body").animate({ scrollTop: 0 }, 500);
  });

  $("#navbar-toggle").click(e => {
    e.preventDefault();
    $("#navbar-menu").toggleClass("is-active");
  });

  $(window).scroll(() => {
    if ($(this).scrollTop() > 50) {
      $("#scroll-to-top").fadeIn("slow");
      $("#navbar").toggleClass("is-spaced", false);
    } else {
      $("#scroll-to-top").fadeOut("slow");
      $("#navbar").toggleClass("is-spaced", true);
    }
  });

  bulmaCarousel.attach("#carousel-demo", {
    slidesToShow: 1,
    pagination: true,
    navigation: false
  });
});
